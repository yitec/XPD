-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 07, 2013 at 05:20 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `bd_xpd`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_agenda`
-- 

CREATE TABLE `tbl_agenda` (
  `id` bigint(20) NOT NULL auto_increment,
  `id_usuario` bigint(20) NOT NULL,
  `evento` text collate utf8_spanish_ci NOT NULL,
  `estado` smallint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla para el control de agendas' AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `tbl_agenda`
-- 

INSERT INTO `tbl_agenda` VALUES (1, 1, 'Mon Nov 26 2012 15:45:00 GMT-0600 (Central America Standard Time)/Mon Nov 26 2012 16:45:00 GMT-0600 (Central America Standard Time)/Cita numero 1', 1);
INSERT INTO `tbl_agenda` VALUES (9, 1, 'Tue Nov 27 2012 14:00:00 GMT-0600 (Central America Standard Time)/Tue Nov 27 2012 15:30:00 GMT-0600 (Central America Standard Time)/Test/Alimentación', 1);
INSERT INTO `tbl_agenda` VALUES (11, 1, 'Wed Nov 28 2012 16:30:00 GMT-0600 (Central America Standard Time)/Wed Nov 28 2012 17:00:00 GMT-0600 (Central America Standard Time)/testing 4:30/A 5:30', 1);
INSERT INTO `tbl_agenda` VALUES (12, 1, 'Tue Nov 27 2012 16:00:00 GMT-0600 (Central America Standard Time)/Tue Nov 27 2012 16:30:00 GMT-0600 (Central America Standard Time)/Tildes/Tildes áéíóú', 1);
INSERT INTO `tbl_agenda` VALUES (13, 1, 'Wed Nov 28 2012 15:45:00 GMT-0600 (Central America Standard Time)/Wed Nov 28 2012 16:15:00 GMT-0600 (Central America Standard Time)/áéíóí/á´séíó', 1);
INSERT INTO `tbl_agenda` VALUES (14, 1, 'Mon Dec 17 2012 13:45:00 GMT-0600 (Central America Standard Time)/Mon Dec 17 2012 14:15:00 GMT-0600 (Central America Standard Time)//', 1);
INSERT INTO `tbl_agenda` VALUES (15, 1, 'Sat Jan 26 2013 08:45:00 GMT-0600 (Hora estándar, América Central)/Sat Jan 26 2013 09:15:00 GMT-0600 (Hora estándar, América Central)/test/Test', 1);
INSERT INTO `tbl_agenda` VALUES (16, 1, 'Sat Jan 26 2013 10:00:00 GMT-0600/Sat Jan 26 2013 13:00:00 GMT-0600/sdfsdf/dfsdf', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_archivos`
-- 

CREATE TABLE `tbl_archivos` (
  `id` int(11) NOT NULL auto_increment,
  `id_expediente` bigint(20) NOT NULL,
  `nombre_archivo` varchar(150) collate utf8_spanish_ci NOT NULL,
  `descripcion` varchar(200) collate utf8_spanish_ci NOT NULL,
  `fecha_creacion` datetime default NULL,
  `fecha_modificacion` datetime default NULL,
  `id_tipo` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Datos de los archivos de expediente' AUTO_INCREMENT=18 ;

-- 
-- Dumping data for table `tbl_archivos`
-- 

INSERT INTO `tbl_archivos` VALUES (1, 24, 'Agenda de Juicio', '', '1988-02-11 12:17:33', '2013-02-27 12:17:41', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (2, 24, 'Citacion Juridica', '', '2013-02-22 12:18:04', '2013-02-20 12:18:08', 2, 1, 1);
INSERT INTO `tbl_archivos` VALUES (3, 0, '1358205356_Database_1.png', '', '2013-03-01 12:14:39', '2013-03-01 12:14:39', 2, 1, 0);
INSERT INTO `tbl_archivos` VALUES (4, 0, '1358205356_Database_1.png', '', '2013-03-01 12:16:55', '2013-03-01 12:16:55', 1, 1, 0);
INSERT INTO `tbl_archivos` VALUES (5, 0, '1358205356_Database_1.png', '', '2013-03-01 12:22:28', '2013-03-01 12:22:28', 1, 1, 0);
INSERT INTO `tbl_archivos` VALUES (6, 24, '1358205356_Database_1.png', '', '2013-03-01 12:25:10', '2013-03-01 12:25:10', 1, 1, 0);
INSERT INTO `tbl_archivos` VALUES (7, 24, '1358205356_Database_1.png', '', '2013-03-01 16:44:05', '2013-03-01 16:44:05', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (8, 24, '1358205356_Database_1.png', '', '2013-03-01 16:55:14', '2013-03-01 16:55:14', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (9, 24, '1358205356_Database_1.png', '', '2013-03-01 16:56:18', '2013-03-01 16:56:18', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (10, 24, '1358205356_Database_1.png', '', '2013-03-01 16:58:08', '2013-03-01 16:58:08', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (11, 24, '1358205356_Database_1.png', '', '2013-03-01 17:02:36', '2013-03-01 17:02:36', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (12, 24, '1358205356_Database_1.png', '', '2013-03-01 17:03:42', '2013-03-01 17:03:42', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (13, 24, '1358205356_Database_1.png', '', '2013-03-01 17:09:03', '2013-03-01 17:09:03', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (14, 24, '1358205356_Database_1.png', '', '2013-03-01 17:09:50', '2013-03-01 17:09:50', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (15, 24, '1358205356_Database_1.png', '', '2013-03-01 17:10:30', '2013-03-01 17:10:30', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (16, 24, '1358205356_Database_1.png', '', '2013-03-01 17:11:24', '2013-03-01 17:11:24', 1, 1, 1);
INSERT INTO `tbl_archivos` VALUES (17, 24, 'TECCR-AZUL (1).png', 'Acta Judicial', '2013-03-04 11:14:04', '2013-03-04 11:14:04', 1, 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_catexpedientes`
-- 

CREATE TABLE `tbl_catexpedientes` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla categorias de expedientes' AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `tbl_catexpedientes`
-- 

INSERT INTO `tbl_catexpedientes` VALUES (1, 'Administrativo', 1);
INSERT INTO `tbl_catexpedientes` VALUES (2, 'Judicial', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_clientes`
-- 

CREATE TABLE `tbl_clientes` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(200) collate utf8_spanish_ci NOT NULL,
  `cedula` varchar(25) collate utf8_spanish_ci NOT NULL,
  `email` varchar(150) collate utf8_spanish_ci NOT NULL,
  `id_tipoCliente` int(11) NOT NULL,
  `tel_cel` varchar(25) collate utf8_spanish_ci NOT NULL,
  `tel_fijo` varchar(25) collate utf8_spanish_ci NOT NULL,
  `fax` varchar(25) collate utf8_spanish_ci NOT NULL,
  `direccion` varchar(100) collate utf8_spanish_ci NOT NULL,
  `credito` tinyint(1) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla de clientes' AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `tbl_clientes`
-- 

INSERT INTO `tbl_clientes` VALUES (1, 'Sergio Barrantes Mayorga', '4-175-575', 'sergio.barrantes@hotmail.com', 1, '8874-0947', '2239-5206', '2344-5667', 'San Antonio de Belén', 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_cobros`
-- 

CREATE TABLE `tbl_cobros` (
  `id` bigint(20) NOT NULL auto_increment,
  `id_expediente` bigint(20) NOT NULL,
  `monto` bigint(20) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `fecha_pago` datetime NOT NULL,
  `id_tipoPago` int(11) NOT NULL,
  `estado` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla para el control de cobros' AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `tbl_cobros`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_expedientes`
-- 

CREATE TABLE `tbl_expedientes` (
  `id` int(11) NOT NULL auto_increment,
  `numero` varchar(100) collate utf8_spanish_ci NOT NULL,
  `titulo` varchar(150) collate utf8_spanish_ci NOT NULL,
  `id_tipoExpediente` int(11) default NULL,
  `fecha_creacion` datetime NOT NULL,
  `fecha_modificacion` datetime NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `numero` (`numero`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=27 ;

-- 
-- Dumping data for table `tbl_expedientes`
-- 

INSERT INTO `tbl_expedientes` VALUES (1, 'SER-23345', '', 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (2, 'asdaf', '', 2, '2013-01-31 13:30:27', '2013-01-31 13:30:27', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (4, 'SER-456565', '', 2, '2013-01-31 13:49:03', '2013-01-31 13:49:03', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (5, 'SER-5456', '', 1, '2013-01-31 13:50:43', '2013-01-31 13:50:43', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (6, '123456', '', 1, '2013-01-31 14:58:19', '2013-01-31 14:58:19', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (7, '1234567', '', 1, '2013-01-31 15:24:24', '2013-01-31 15:24:24', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (8, '12345678', '', 1, '2013-01-31 15:40:07', '2013-01-31 15:40:07', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (9, 'SER12345678', '', 1, '2013-02-01 11:52:44', '2013-02-01 11:52:44', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (10, 'SER-6767867', '', 1, '2013-02-01 11:54:37', '2013-02-01 11:54:37', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (11, 'Ser-12312321', '', 1, '2013-02-01 11:56:12', '2013-02-01 11:56:12', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (12, 'Seert-2155435', '', 1, '2013-02-01 11:58:24', '2013-02-01 11:58:24', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (13, 'sdfsdfsdf', '', 1, '2013-02-01 11:59:06', '2013-02-01 11:59:06', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (14, 'asd12321', '', 1, '2013-02-01 12:03:37', '2013-02-01 12:03:37', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (15, '5456456', '', 1, '2013-02-01 12:21:04', '2013-02-01 12:21:04', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (16, 'gfhf65765', '', 1, '2013-02-01 12:34:16', '2013-02-01 12:34:16', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (17, 'sdgfg435', '', 1, '2013-02-01 15:35:12', '2013-02-01 15:35:12', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (18, 'sdgdf21213', '', 1, '2013-02-01 15:38:59', '2013-02-01 15:38:59', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (19, 'ewrewrwerwer', '', 1, '2013-02-01 17:43:59', '2013-02-01 17:43:59', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (20, 'ssfsdfdf6', '', 1, '2013-02-01 17:45:40', '2013-02-01 17:45:40', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (21, 'sdfsdfsdf676', '', 1, '2013-02-01 17:47:03', '2013-02-01 17:47:03', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (22, '23343423', 'Caso Divorcio', 1, '2013-02-05 16:31:20', '2013-02-05 16:31:20', 1, 1, 1);
INSERT INTO `tbl_expedientes` VALUES (23, 'dsffdgfdg', '', 1, '2013-02-05 16:33:59', '2013-02-05 16:33:59', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (24, '23554354', 'Caso Demanda Laboral', 1, '2013-02-05 16:35:54', '2013-02-05 16:35:54', 1, 1, 1);
INSERT INTO `tbl_expedientes` VALUES (25, '12345670', '', 2, '2013-03-07 17:09:25', '2013-03-07 17:09:25', 1, 0, 1);
INSERT INTO `tbl_expedientes` VALUES (26, '123123', 'Caso Fincas', 2, '2013-03-07 17:13:31', '2013-03-07 17:13:31', 1, 0, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_reportes`
-- 

CREATE TABLE `tbl_reportes` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `link` varchar(100) collate utf8_spanish_ci NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla para el control de los reportes' AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `tbl_reportes`
-- 

INSERT INTO `tbl_reportes` VALUES (1, 'Cobros entre fechas', 'mcobros_fechas.php', 1);
INSERT INTO `tbl_reportes` VALUES (2, 'Total expedientes', 'total_expedientes.php', 1);
INSERT INTO `tbl_reportes` VALUES (3, 'Pagos entre fechas', 'mpagos_fechas', 1);
INSERT INTO `tbl_reportes` VALUES (4, 'Listado de clientes', 'listado_clientes.php', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_tipoarchivo`
-- 

CREATE TABLE `tbl_tipoarchivo` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `estado` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla tipos de archivos que se puede subir' AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `tbl_tipoarchivo`
-- 

INSERT INTO `tbl_tipoarchivo` VALUES (1, 'Excel', 1);
INSERT INTO `tbl_tipoarchivo` VALUES (2, 'Word', 1);
INSERT INTO `tbl_tipoarchivo` VALUES (3, 'Texto', 1);
INSERT INTO `tbl_tipoarchivo` VALUES (4, 'Video', 1);
INSERT INTO `tbl_tipoarchivo` VALUES (5, 'Audio', 1);
INSERT INTO `tbl_tipoarchivo` VALUES (6, 'Pdf', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_tipocliente`
-- 

CREATE TABLE `tbl_tipocliente` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla con los tipos de clientes' AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `tbl_tipocliente`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_tipoexpedientes`
-- 

CREATE TABLE `tbl_tipoexpedientes` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla tipos de expedientes' AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `tbl_tipoexpedientes`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_tipopago`
-- 

CREATE TABLE `tbl_tipopago` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `tbl_tipopago`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_usuarios`
-- 

CREATE TABLE `tbl_usuarios` (
  `id` int(11) NOT NULL auto_increment,
  `ids_accesos` varchar(100) collate utf8_spanish_ci NOT NULL,
  `ids_reportes` varchar(100) collate utf8_spanish_ci NOT NULL,
  `cedula` varchar(50) collate utf8_spanish_ci NOT NULL,
  `nombre` varchar(50) collate utf8_spanish_ci NOT NULL,
  `apellidos` varchar(150) collate utf8_spanish_ci NOT NULL,
  `usuario` varchar(20) collate utf8_spanish_ci NOT NULL,
  `clave` varchar(20) collate utf8_spanish_ci NOT NULL,
  `correo` varchar(150) collate utf8_spanish_ci NOT NULL,
  `telefono` varchar(25) collate utf8_spanish_ci NOT NULL,
  `fecha_vencimiento` datetime NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla para el control de usuario' AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `tbl_usuarios`
-- 

INSERT INTO `tbl_usuarios` VALUES (1, '1,2,3,4,5,6,7,8', '1,2,3,4,5,6,7,8', '4-175-575', 'Sergio', 'Barrantes Mizard', 'sid', 'mizard777', 'sbarrantes@yitec.net', '88300417', '2020-01-22 15:38:21', 1);
